import {
    requireAuth
} from '../auth/authGuard.js';

import {
    documentApi
} from '../api/documentApi.js';

import {
    folderApi
} from '../api/folderApi.js';

import {
    documentShareApi
} from '../api/documentShareApi.js';

import {
    fileSize
} from '../utils/formatters.js';


// =========================================================
// DOCUMENT PAGE
// =========================================================
//
// OWN DOCUMENT FEATURES:
//
// ✅ Upload
// ✅ List
// ✅ Details
// ✅ Download
// ✅ Rename
// ✅ Delete
//
// SECURE SHARING:
//
// ✅ Share
// ✅ Recipient email
// ✅ Invitation email
// ✅ Pending / Accepted / Revoked
// ✅ Manage shares
// ✅ Revoke
//
// =========================================================


const MAX_FILE_SIZE =
    10 * 1024 * 1024;


const ALLOWED_EXTENSIONS =
    [
        '.pdf',
        '.doc',
        '.docx',
        '.jpg',
        '.jpeg',
        '.png'
    ];


// =========================================================
// AUTH
// =========================================================

const authenticated =
    requireAuth();


// =========================================================
// DOCUMENT ELEMENTS
// =========================================================

const form =
    document.getElementById(
        'documentForm');


const fileInput =
    form?.querySelector(
        '[name="file"]');


const folderSelect =
    form?.querySelector(
        '[name="folderId"]');


const uploadButton =
    document.getElementById(
        'uploadButton');


const list =
    document.getElementById(
        'list');


const message =
    document.getElementById(
        'message');


const detailsSection =
    document.getElementById(
        'details');


const detailsContent =
    document.getElementById(
        'detailsContent');


// =========================================================
// SHARE ELEMENTS
// =========================================================

const sharePanel =
    document.getElementById(
        'sharePanel');


const sharePanelTitle =
    document.getElementById(
        'sharePanelTitle');


const shareDocumentName =
    document.getElementById(
        'shareDocumentName');


const shareForm =
    document.getElementById(
        'shareForm');


const recipientEmailInput =
    shareForm?.querySelector(
        '[name="recipientEmail"]');


const sendShareButton =
    document.getElementById(
        'sendShareButton');


const closeShareButton =
    document.getElementById(
        'closeShareButton');


const shareList =
    document.getElementById(
        'shareList');


// =========================================================
// STATE
// =========================================================

const folderNames =
    new Map();


let selectedShareDocument =
    null;


// =========================================================
// START
// =========================================================

if (authenticated) {

    initializeDocumentPage();
}


// =========================================================
// INITIALIZE
// =========================================================

async function initializeDocumentPage() {

    await loadFolders();

    await loadDocuments();
}


// =========================================================
// LOAD FOLDERS
// =========================================================

async function loadFolders() {

    try {

        const result =
            await folderApi.all();


        const folders =
            Array.isArray(result)
                ? result
                : [];


        folderNames.clear();


        folderSelect
            ?.replaceChildren();


        const emptyOption =
            document.createElement(
                'option');


        emptyOption.value =
            '';


        emptyOption.textContent =
            'No folder';


        folderSelect
            ?.appendChild(
                emptyOption);


        folders.forEach(
            folder => {
                const id =
                    Number(folder?.id);


                if (!Number.isInteger(id) ||
                    id <= 0) {

                    return;
                }


                const name =
                    folder?.name ||
                    `Folder ${id}`;


                folderNames.set(
                    id,
                    name);


                const option =
                    document.createElement(
                        'option');


                option.value =
                    String(id);


                option.textContent =
                    name;


                folderSelect
                    ?.appendChild(
                        option);
            });
    }
    catch (error) {

        showMessage(
            error.message ||
            'Folders could not be loaded.');
    }
}


// =========================================================
// LOAD DOCUMENTS
// =========================================================

async function loadDocuments() {

    showMessage(
        'Loading documents...');


    try {

        const result =
            await documentApi.all();


        const documents =
            Array.isArray(result)
                ? result
                : [];


        renderDocuments(
            documents);


        showMessage(
            '');
    }
    catch (error) {

        list?.replaceChildren();


        showMessage(
            error.message ||
            'Documents could not be loaded.');
    }
}


// =========================================================
// UPLOAD
// =========================================================

form?.addEventListener(
    'submit',
    async event => {
        event.preventDefault();


        if (!requireAuth()) {
            return;
        }


        const file =
            fileInput?.files?.[0];


        if (!file) {

            showMessage(
                'Please select a document.');

            return;
        }


        const extension =
            getExtension(
                file.name);


        if (!ALLOWED_EXTENSIONS.includes(
            extension)) {

            showMessage(
                'Allowed files: PDF, DOC, DOCX, JPG, JPEG and PNG.');

            return;
        }


        if (file.size <= 0) {

            showMessage(
                'The selected file is empty.');

            return;
        }


        if (file.size >
            MAX_FILE_SIZE) {

            showMessage(
                'The selected file must not exceed 10 MB.');

            return;
        }


        const formData =
            new FormData();


        formData.append(
            'file',
            file);


        const folderId =
            folderSelect?.value
                ?.trim();


        if (folderId) {

            formData.append(
                'folderId',
                folderId);
        }


        setButtonDisabled(
            uploadButton,
            true);


        showMessage(
            'Uploading and securing document...');


        try {

            await documentApi
                .upload(
                    formData);


            form.reset();


            clearDetails();

            closeSharePanel();


            await loadDocuments();


            showMessage(
                'Document uploaded successfully.');
        }
        catch (error) {

            showMessage(
                error.message ||
                'Document could not be uploaded.');
        }
        finally {

            setButtonDisabled(
                uploadButton,
                false);
        }
    });


// =========================================================
// RENDER DOCUMENTS
// =========================================================

function renderDocuments(
    documents) {

    if (!list) {
        return;
    }


    list.replaceChildren();


    if (documents.length === 0) {

        const empty =
            document.createElement(
                'div');


        empty.className =
            'card vault-item';


        empty.textContent =
            'No documents uploaded yet.';


        list.appendChild(
            empty);


        return;
    }


    documents.forEach(
        item => {
            list.appendChild(
                createDocumentCard(
                    item));
        });
}


// =========================================================
// DOCUMENT CARD
// =========================================================

function createDocumentCard(
    item) {

    const card =
        document.createElement(
            'div');


    card.className =
        'card vault-item';


    const information =
        document.createElement(
            'div');


    const name =
        document.createElement(
            'strong');


    name.textContent =
        item?.fileName ||
        'Unnamed document';


    const metadata =
        document.createElement(
            'div');


    metadata.textContent =
        `${fileSize(
            Number(item?.fileSize || 0)
        )} · ${getFolderName(
            item?.folderId
        )}`;


    information.appendChild(
        name);


    information.appendChild(
        metadata);


    const actions =
        document.createElement(
            'div');


    actions.className =
        'vault-actions';


    // =====================================================
    // DETAILS
    // =====================================================

    const detailsButton =
        createButton(
            'Details');


    detailsButton.addEventListener(
        'click',
        async () => {
            await showDocumentDetails(
                item,
                detailsButton);
        });


    // =====================================================
    // DOWNLOAD
    // =====================================================

    const downloadButton =
        createButton(
            'Download');


    downloadButton.addEventListener(
        'click',
        async () => {
            await downloadDocument(
                item,
                downloadButton);
        });


    // =====================================================
    // RENAME
    // =====================================================

    const renameButton =
        createButton(
            'Rename');


    renameButton.addEventListener(
        'click',
        async () => {
            await renameDocument(
                item,
                renameButton);
        });


    // =====================================================
    // SHARE
    // =====================================================

    const shareButton =
        createButton(
            'Share');


    shareButton.addEventListener(
        'click',
        async () => {
            await openSharePanel(
                item,
                true);
        });


    // =====================================================
    // MANAGE SHARES
    // =====================================================

    const manageSharesButton =
        createButton(
            'Shared With');


    manageSharesButton.addEventListener(
        'click',
        async () => {
            await openSharePanel(
                item,
                false);
        });


    // =====================================================
    // DELETE
    // =====================================================

    const deleteButton =
        createButton(
            'Delete');


    deleteButton.addEventListener(
        'click',
        async () => {
            await deleteDocument(
                item,
                deleteButton);
        });


    actions.append(
        detailsButton,
        downloadButton,
        renameButton,
        shareButton,
        manageSharesButton,
        deleteButton);


    card.append(
        information,
        actions);


    return card;
}


// =========================================================
// DETAILS
// =========================================================

async function showDocumentDetails(
    item,
    button) {

    const id =
        getDocumentId(
            item);


    if (!id) {
        return;
    }


    setButtonDisabled(
        button,
        true);


    try {

        const details =
            await documentApi.get(
                id);


        renderDocumentDetails(
            details);
    }
    catch (error) {

        showMessage(
            error.message ||
            'Document details could not be loaded.');
    }
    finally {

        setButtonDisabled(
            button,
            false);
    }
}


function renderDocumentDetails(
    details) {

    if (!detailsSection ||
        !detailsContent) {

        return;
    }


    detailsContent.replaceChildren();


    appendDetail(
        detailsContent,
        'File Name',
        details?.fileName || '-');


    appendDetail(
        detailsContent,
        'Type',
        details?.contentType || '-');


    appendDetail(
        detailsContent,
        'Size',
        fileSize(
            Number(
                details?.fileSize || 0)));


    appendDetail(
        detailsContent,
        'Folder',
        getFolderName(
            details?.folderId));


    appendDetail(
        detailsContent,
        'Uploaded',
        formatDate(
            details?.createdAt));


    detailsSection.hidden =
        false;
}


// =========================================================
// DOWNLOAD
// =========================================================

async function downloadDocument(
    item,
    button) {

    const id =
        getDocumentId(
            item);


    if (!id) {
        return;
    }


    setButtonDisabled(
        button,
        true);


    try {

        await documentApi
            .download(
                id,
                item.fileName);


        showMessage(
            'Document downloaded successfully.');
    }
    catch (error) {

        showMessage(
            error.message ||
            'Document could not be downloaded.');
    }
    finally {

        setButtonDisabled(
            button,
            false);
    }
}


// =========================================================
// RENAME
// =========================================================

async function renameDocument(
    item,
    button) {

    const id =
        getDocumentId(
            item);


    if (!id) {
        return;
    }


    const oldName =
        item?.fileName || '';


    const input =
        window.prompt(
            'Enter the new document name:',
            oldName);


    if (input === null) {
        return;
    }


    const newName =
        input.trim();


    if (!newName) {

        showMessage(
            'Document name cannot be empty.');

        return;
    }


    if (getExtension(oldName) !==
        getExtension(newName)) {

        showMessage(
            'The file extension cannot be changed.');

        return;
    }


    setButtonDisabled(
        button,
        true);


    try {

        await documentApi
            .rename(
                id,
                {
                    fileName:
                        newName
                });


        clearDetails();

        closeSharePanel();

        await loadDocuments();


        showMessage(
            'Document renamed successfully.');
    }
    catch (error) {

        showMessage(
            error.message ||
            'Document could not be renamed.');
    }
    finally {

        setButtonDisabled(
            button,
            false);
    }
}


// =========================================================
// DELETE
// =========================================================

async function deleteDocument(
    item,
    button) {

    const id =
        getDocumentId(
            item);


    if (!id) {
        return;
    }


    const confirmed =
        window.confirm(
            `Delete "${item?.fileName || 'this document'}" permanently?`);


    if (!confirmed) {
        return;
    }


    setButtonDisabled(
        button,
        true);


    try {

        await documentApi
            .remove(
                id);


        clearDetails();

        closeSharePanel();

        await loadDocuments();


        showMessage(
            'Document deleted successfully.');
    }
    catch (error) {

        showMessage(
            error.message ||
            'Document could not be deleted.');
    }
    finally {

        setButtonDisabled(
            button,
            false);
    }
}


// =========================================================
// OPEN SHARE PANEL
// =========================================================

async function openSharePanel(
    documentItem,
    focusEmail) {

    const id =
        getDocumentId(
            documentItem);


    if (!id ||
        !sharePanel) {

        showMessage(
            'Invalid document.');

        return;
    }


    selectedShareDocument =
        documentItem;


    if (shareDocumentName) {

        shareDocumentName.textContent =
            `Document: ${documentItem.fileName}`;
    }


    if (sharePanelTitle) {

        sharePanelTitle.textContent =
            'Secure Document Sharing';
    }


    sharePanel.hidden =
        false;


    recipientEmailInput.value =
        '';


    await loadDocumentShares();


    if (focusEmail) {

        recipientEmailInput
            ?.focus();
    }


    sharePanel.scrollIntoView(
        {
            behavior:
                'smooth',

            block:
                'start'
        });
}


// =========================================================
// SEND SHARE INVITATION
// =========================================================

shareForm?.addEventListener(
    'submit',
    async event => {
        event.preventDefault();


        if (!requireAuth()) {
            return;
        }


        const documentId =
            getDocumentId(
                selectedShareDocument);


        if (!documentId) {

            showMessage(
                'Select a document first.');

            return;
        }


        const recipientEmail =
            recipientEmailInput
                ?.value
                ?.trim()
                .toLowerCase()
            || '';


        if (!recipientEmail) {

            showMessage(
                'Recipient email is required.');

            return;
        }


        setButtonDisabled(
            sendShareButton,
            true);


        showMessage(
            'Creating secure invitation...');


        try {

            const share =
                await documentShareApi
                    .share(
                        documentId,
                        recipientEmail);


            // Raw token intentionally unavailable here.
            recipientEmailInput.value =
                '';


            await loadDocumentShares();


            showMessage(
                `Secure invitation sent to ${share?.recipientEmail || recipientEmail}.`);
        }
        catch (error) {

            showMessage(
                error.message ||
                'The document could not be shared with this recipient.');
        }
        finally {

            setButtonDisabled(
                sendShareButton,
                false);
        }
    });


// =========================================================
// LOAD OWNER SHARE LIST
// =========================================================

async function loadDocumentShares() {

    if (!shareList) {
        return;
    }


    const documentId =
        getDocumentId(
            selectedShareDocument);


    if (!documentId) {
        return;
    }


    shareList.replaceChildren();


    const loading =
        document.createElement(
            'div');


    loading.textContent =
        'Loading share status...';


    shareList.appendChild(
        loading);


    try {

        const response =
            await documentShareApi
                .getDocumentShares(
                    documentId);


        const shares =
            Array.isArray(response)
                ? response
                : [];


        renderDocumentShares(
            shares);
    }
    catch (error) {

        shareList.replaceChildren();


        const failed =
            document.createElement(
                'div');


        failed.textContent =
            error.message ||
            'Share information could not be loaded.';


        shareList.appendChild(
            failed);
    }
}


// =========================================================
// RENDER SHARES
// =========================================================

function renderDocumentShares(
    shares) {

    shareList.replaceChildren();


    if (shares.length === 0) {

        const empty =
            document.createElement(
                'div');


        empty.textContent =
            'This document has not been shared yet.';


        shareList.appendChild(
            empty);


        return;
    }


    shares.forEach(
        share => {
            shareList.appendChild(
                createShareCard(
                    share));
        });
}


// =========================================================
// SHARE CARD
// =========================================================

function createShareCard(
    share) {

    const card =
        document.createElement(
            'div');


    card.className =
        'card vault-item';


    const info =
        document.createElement(
            'div');


    const recipient =
        document.createElement(
            'strong');


    recipient.textContent =
        share?.recipientName ||
        'Recipient';


    const email =
        document.createElement(
            'div');


    email.textContent =
        share?.recipientEmail ||
        '-';


    const status =
        document.createElement(
            'div');


    status.textContent =
        `Status: ${formatShareStatus(
            share?.status
        )}`;


    const shared =
        document.createElement(
            'div');


    shared.textContent =
        `Shared: ${formatDate(
            share?.sharedAt
        )}`;


    const expiry =
        document.createElement(
            'div');


    expiry.textContent =
        `Invitation expires: ${formatDate(
            share?.expiresAt
        )}`;


    info.append(
        recipient,
        email,
        status,
        shared,
        expiry);


    if (share?.acceptedAt) {

        const accepted =
            document.createElement(
                'div');


        accepted.textContent =
            `Accepted: ${formatDate(
                share.acceptedAt
            )}`;


        info.appendChild(
            accepted);
    }


    if (share?.revokedAt) {

        const revoked =
            document.createElement(
                'div');


        revoked.textContent =
            `Revoked: ${formatDate(
                share.revokedAt
            )}`;


        info.appendChild(
            revoked);
    }


    const actions =
        document.createElement(
            'div');


    actions.className =
        'vault-actions';


    const revokeButton =
        createButton(
            'Revoke');


    revokeButton.addEventListener(
        'click',
        async () => {
            await revokeShare(
                share,
                revokeButton);
        });


    actions.appendChild(
        revokeButton);


    card.append(
        info,
        actions);


    return card;
}


// =========================================================
// REVOKE
// =========================================================

async function revokeShare(
    share,
    button) {

    const documentId =
        getDocumentId(
            selectedShareDocument);


    const shareId =
        Number(
            share?.shareId);


    if (!documentId ||
        !Number.isInteger(shareId) ||
        shareId <= 0) {

        showMessage(
            'Invalid share.');

        return;
    }


    const confirmed =
        window.confirm(
            `Revoke access for ${share?.recipientEmail || 'this recipient'}?`);


    if (!confirmed) {
        return;
    }


    setButtonDisabled(
        button,
        true);


    try {

        await documentShareApi
            .revoke(
                documentId,
                shareId);


        await loadDocumentShares();


        showMessage(
            'Document share revoked successfully.');
    }
    catch (error) {

        showMessage(
            error.message ||
            'Document share could not be revoked.');
    }
    finally {

        setButtonDisabled(
            button,
            false);
    }
}


// =========================================================
// CLOSE SHARE PANEL
// =========================================================

closeShareButton?.addEventListener(
    'click',
    () => {
        closeSharePanel();
    });


function closeSharePanel() {

    selectedShareDocument =
        null;


    shareForm?.reset();


    shareList
        ?.replaceChildren();


    if (sharePanel) {

        sharePanel.hidden =
            true;
    }
}


// =========================================================
// HELPERS
// =========================================================

function getDocumentId(
    item) {

    const id =
        Number(
            item?.id);


    return Number.isInteger(id) &&
        id > 0
        ?
        id
        :
        null;
}


function getFolderName(
    folderId) {

    if (folderId === null ||
        folderId === undefined ||
        folderId === '') {

        return 'No folder';
    }


    return folderNames.get(
        Number(folderId))
        ||
        `Folder ${folderId}`;
}


function getExtension(
    fileName) {

    if (!fileName) {
        return '';
    }


    const position =
        fileName.lastIndexOf('.');


    if (position <= 0) {
        return '';
    }


    return fileName
        .slice(position)
        .toLowerCase();
}


function formatDate(
    value) {

    if (!value) {
        return '-';
    }


    const date =
        new Date(value);


    return Number.isNaN(
        date.getTime())
        ?
        '-'
        :
        date.toLocaleString();
}


// =========================================================
// SHARE STATUS
// =========================================================
//
// JsonStringEnumConverter irundha:
//
// Pending
// Accepted
// Revoked
//
// Numeric serialization irundhaal common enum order:
//
// 0 Pending
// 1 Accepted
// 2 Revoked
//
// rendu format-um display handle pannuvom.
function formatShareStatus(
    value) {

    const text =
        String(
            value ?? '')
            .trim();


    if (text === '0') {
        return 'Pending';
    }


    if (text === '1') {
        return 'Accepted';
    }


    if (text === '2') {
        return 'Revoked';
    }


    if (!text) {
        return 'Unknown';
    }


    return text;
}


function createButton(
    text) {

    const button =
        document.createElement(
            'button');


    button.type =
        'button';


    button.textContent =
        text;


    return button;
}


function appendDetail(
    container,
    label,
    value) {

    const row =
        document.createElement(
            'p');


    const strong =
        document.createElement(
            'strong');


    strong.textContent =
        `${label}: `;


    const span =
        document.createElement(
            'span');


    span.textContent =
        String(value);


    row.append(
        strong,
        span);


    container.appendChild(
        row);
}


function clearDetails() {

    detailsContent
        ?.replaceChildren();


    if (detailsSection) {

        detailsSection.hidden =
            true;
    }
}


function setButtonDisabled(
    button,
    disabled) {

    if (button) {

        button.disabled =
            disabled;
    }
}


function showMessage(
    text) {

    if (message) {

        message.textContent =
            text;
    }
}