import {
    api
} from './apiClient.js';


// =========================================================
// AUTH API
// =========================================================
//
// PURPOSE:
//
// Authentication related backend endpoints
// ellathayum ore place-la maintain pannuvom.
//
// Page JS direct fetch() use panna vendaam.
//
// Page JS
//    ↓
// authApi
//    ↓
// apiClient
//    ↓
// ASP.NET Core AuthController
//
// =========================================================

export const authApi =
{
    // =====================================================
    // 1. REGISTER
    // =====================================================
    //
    // POST /api/auth/register
    //
    // Input:
    //
    // {
    //     fullName,
    //     email,
    //     password
    // }
    //
    // Output:
    // Generic registration response.
    //
    // IMPORTANT:
    // Final JWT inga return aaga koodathu.
    register:
        data =>
            api(
                '/auth/register',
                {
                    method:
                        'POST',

                    body:
                        JSON.stringify(
                            data)
                }),


    // =====================================================
    // 2. VERIFY EMAIL OTP
    // =====================================================
    //
    // POST /api/auth/verify-email
    //
    // Input:
    //
    // {
    //     email,
    //     otp
    // }
    //
    // Success:
    // Temporary TOTP setup token return aagum.
    verifyEmail:
        data =>
            api(
                '/auth/verify-email',
                {
                    method:
                        'POST',

                    body:
                        JSON.stringify(
                            data)
                }),


    // =====================================================
    // 3. RESEND EMAIL OTP
    // =====================================================
    //
    // POST /api/auth/resend-email-otp
    //
    // Input:
    //
    // {
    //     email
    // }
    //
    // Backend generic response use pannum
    // account enumeration avoid panna.
    resendEmailOtp:
        data =>
            api(
                '/auth/resend-email-otp',
                {
                    method:
                        'POST',

                    body:
                        JSON.stringify(
                            data)
                }),


    // =====================================================
    // 4. SETUP TOTP
    // =====================================================
    //
    // POST /api/auth/setup-totp
    //
    // Input:
    //
    // {
    //     setupToken
    // }
    //
    // Output:
    //
    // secretKey
    // otpAuthUri
    // qrCodeDataUrl
    //
    // IMPORTANT:
    // setupToken final JWT illa.
    setupTotp:
        data =>
            api(
                '/auth/setup-totp',
                {
                    method:
                        'POST',

                    body:
                        JSON.stringify(
                            data)
                }),


    // =====================================================
    // 5. VERIFY TOTP SETUP
    // =====================================================
    //
    // POST /api/auth/verify-totp-setup
    //
    // Input:
    //
    // {
    //     setupToken,
    //     code
    // }
    //
    // Success:
    // User TOTP setup complete.
    verifyTotpSetup:
        data =>
            api(
                '/auth/verify-totp-setup',
                {
                    method:
                        'POST',

                    body:
                        JSON.stringify(
                            data)
                }),


    // =====================================================
    // 6. LOGIN PASSWORD STEP
    // =====================================================
    //
    // POST /api/auth/login
    //
    // Normal User:
    //
    // password success
    //      ↓
    // requiresTotp = true
    // challengeToken = temporary token
    // token = null
    //
    // Admin:
    //
    // requiresTotp = false
    // token = final JWT
    login:
        data =>
            api(
                '/auth/login',
                {
                    method:
                        'POST',

                    body:
                        JSON.stringify(
                            data)
                }),


    // =====================================================
    // 7. VERIFY LOGIN TOTP
    // =====================================================
    //
    // POST /api/auth/verify-login-totp
    //
    // Input:
    //
    // {
    //     challengeToken,
    //     code
    // }
    //
    // Success:
    // FINAL access JWT return aagum.
    verifyLoginTotp:
        data =>
            api(
                '/auth/verify-login-totp',
                {
                    method:
                        'POST',

                    body:
                        JSON.stringify(
                            data)
                }),


    // =====================================================
    // 8. LOGOUT
    // =====================================================
    //
    // POST /api/auth/logout
    //
    // Current JWT server endpoint-ku send pannalaam.
    //
    // Browser token cleanup frontend
    // tokenManager handle pannum.
    logout:
        () =>
            api(
                '/auth/logout',
                {
                    method:
                        'POST'
                })
};